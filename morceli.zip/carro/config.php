<?php

class Conexao {
    private static $conn = null;

    public static function getConexao() {
        if (self::$conn === null) {
            $host = 'localhost';
            $user = 'root';
            $password = '';
            $database = 'carros_db';

            try {
                self::$conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->exec("SET NAMES utf8");
            } catch (PDOException $e) {
                echo "Erro: " . $e->getMessage();
                return null;
            }
        }
        
        return self::$conn;
    }
}
?>
