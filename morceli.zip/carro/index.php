<?php

include 'config.php';

$conn = Conexao::getConexao();

if ($conn === null) {
    die("Falha na conexão com o banco de dados."); 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $modelo = $_POST['modelo'] ?? '';
    $marca = $_POST['marca'] ?? '';
    $ano = $_POST['ano'] ?? '';
    $cor = $_POST['cor'] ?? '';

    if (!empty($modelo) && !empty($marca) && !empty($ano) && !empty($cor)) {
        $sql = "INSERT INTO carros (modelo, marca, ano, cor) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$modelo, $marca, $ano, $cor]);
        echo "Carro cadastrado com sucesso!";
    } else {
        echo "Todos os campos são obrigatórios!";
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM carros WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    echo "Carro excluído com sucesso!";
}

$sql = "SELECT * FROM carros";
$stmt = $conn->query($sql);
$carros = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Carros</title>
</head>
<body>

    <h1>Cadastro de Carros</h1>

    <form action="index.php" method="POST">
        <label for="modelo">Modelo:</label>
        <input type="text" name="modelo" required><br><br>

        <label for="marca">Marca:</label>
        <input type="text" name="marca" required><br><br>

        <label for="ano">Ano:</label>
        <input type="number" name="ano" required><br><br>

        <label for="cor">Cor:</label>
        <select name="cor" required>
            <option value="">Selecione</option>
            <option value="Vermelho">Vermelho</option>
            <option value="Azul">Azul</option>
            <option value="Preto">Preto</option>
            <option value="Branco">Branco</option>
        </select><br><br>

        <button type="submit">Cadastrar</button>
    </form>

    <h2>Lista de Carros</h2>
    <table>
        <tr>
            <th>Modelo</th>
            <th>Marca</th>
            <th>Ano</th>
            <th>Cor</th>
            <th>Excluir</th>
        </tr>
        <?php foreach ($carros as $carro): ?>
        <tr>
            <td><?= htmlspecialchars($carro['modelo']) ?></td>
            <td><?= htmlspecialchars($carro['marca']) ?></td>
            <td><?= htmlspecialchars($carro['ano']) ?></td>
            <td><?= htmlspecialchars($carro['cor']) ?></td>
            <td>
                <a href="index.php?delete=<?= $carro['id'] ?>">Excluir</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

</body>
</html>
